@rem Minimal Windows Gradle wrapper launcher
@if "%DEBUG%"=="" @echo off
@setlocal enabledelayedexpansion
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set JAVA_EXE=java.exe
if defined JAVA_HOME set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
"%JAVA_EXE%" -Xmx2048m -jar "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" %*
