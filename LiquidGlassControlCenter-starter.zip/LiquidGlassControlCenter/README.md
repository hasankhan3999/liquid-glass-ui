# Liquid Glass Control Center & Notification Center (Android)

Starter Android Kotlin + Jetpack Compose project ready to upload to a GitHub repository.

## How to Build an APK on GitHub
1. Create a new repository on GitHub (e.g., `liquid-glass-ui`).
2. Extract this ZIP archive and push all files to the `main` branch.
3. Open the **Actions** tab on GitHub — the **Build Android APK** workflow runs `./gradlew assembleDebug` automatically and uploads `LiquidGlassControlCenter-debug-apk` as a downloadable artifact.
