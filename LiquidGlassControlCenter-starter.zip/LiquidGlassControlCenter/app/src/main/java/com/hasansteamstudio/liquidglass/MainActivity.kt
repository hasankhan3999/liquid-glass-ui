package com.hasansteamstudio.liquidglass

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hasansteamstudio.liquidglass.model.NotificationEntry
import com.hasansteamstudio.liquidglass.model.WifiNetworkItem
import com.hasansteamstudio.liquidglass.ui.components.LiquidGlassTile
import com.hasansteamstudio.liquidglass.ui.controlcenter.WifiNetworksPopupModal
import com.hasansteamstudio.liquidglass.ui.notifications.StackedNotificationsList
import com.hasansteamstudio.liquidglass.ui.theme.LiquidGlassTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LiquidGlassTheme {
                LiquidGlassWorkspaceScreen()
            }
        }
    }
}

@Composable
private fun LiquidGlassWorkspaceScreen() {
    val context = LocalContext.current
    var wifiEnabled by remember { mutableStateOf(true) }
    var flashlightEnabled by remember { mutableStateOf(false) }
    var editMode by remember { mutableStateOf(false) }
    var showWifiPopup by remember { mutableStateOf(false) }
    var tintStrength by remember { mutableFloatStateOf(0.22f) }

    val wifiNetworks = remember {
        mutableStateListOf(
            WifiNetworkItem("Home_Fiber_5G", signalLevel = 4, isSecured = true, isConnected = true),
            WifiNetworkItem("SteamStudio_Guest", signalLevel = 3, isSecured = true, isConnected = false),
            WifiNetworkItem("Cafe_Free_WiFi", signalLevel = 2, isSecured = false, isConnected = false)
        )
    }

    val sampleNotifications = remember {
        listOf(
            NotificationEntry("1", "com.whatsapp", "WhatsApp", "Bilal", "Bro kal subah milte hain?", "2m ago"),
            NotificationEntry("2", "com.whatsapp", "WhatsApp", "Adeel", "Nayi photo edit ready hai", "5m ago"),
            NotificationEntry("3", "com.whatsapp", "WhatsApp", "Kamran", "Sab set hai bhai", "12m ago"),
            NotificationEntry("4", "com.youtube", "YouTube", "Studio Update", "New views milestone unlocked", "24m ago"),
            NotificationEntry("5", "com.google.android.gm", "Gmail", "Build Alert", "Workflow run completed", "1h ago")
        )
    }

    val backdropBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF1B2A4A),
            Color(0xFF2D1B3D),
            Color(0xFF0B0D14)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backdropBrush)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "iOS 26/27 Liquid Glass",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.16f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (Settings.canDrawOverlays(context)) "Overlay Ready" else "Enable Overlay",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (tintStrength < 0.26f) "Clear" else "Tinted",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    modifier = Modifier.width(56.dp)
                )
                Slider(
                    value = tintStrength,
                    onValueChange = { tintStrength = it },
                    valueRange = 0.14f..0.46f,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LiquidGlassTile(
                    modifier = Modifier
                        .weight(1f)
                        .height(92.dp),
                    isActive = wifiEnabled,
                    tintStrength = tintStrength,
                    onTap = { wifiEnabled = !wifiEnabled },
                    onLongTap = { showWifiPopup = true }
                ) {
                    Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = Icons.Rounded.Wifi,
                            contentDescription = "Wi-Fi",
                            tint = if (wifiEnabled) Color(0xFF111111) else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Wi-Fi (Hold)",
                            color = if (wifiEnabled) Color(0xFF111111) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                LiquidGlassTile(
                    modifier = Modifier
                        .weight(1f)
                        .height(92.dp),
                    isActive = flashlightEnabled,
                    tintStrength = tintStrength,
                    onTap = { flashlightEnabled = !flashlightEnabled },
                    onLongTap = {
                        if (!Settings.canDrawOverlays(context)) {
                            context.startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                            )
                        }
                    }
                ) {
                    Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = Icons.Rounded.FlashlightOn,
                            contentDescription = "Torch",
                            tint = if (flashlightEnabled) Color(0xFF111111) else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (flashlightEnabled) "Torch On" else "Flashlight",
                            color = if (flashlightEnabled) Color(0xFF111111) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                LiquidGlassTile(
                    modifier = Modifier
                        .weight(1f)
                        .height(92.dp),
                    isActive = editMode,
                    tintStrength = tintStrength,
                    onTap = { editMode = !editMode },
                    onLongTap = { editMode = !editMode }
                ) {
                    Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "Edit",
                            tint = if (editMode) Color(0xFF111111) else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (editMode) "Editing" else "Edit Mode",
                            color = if (editMode) Color(0xFF111111) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Notification Stack",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            StackedNotificationsList(
                notifications = sampleNotifications,
                tintStrength = tintStrength,
                modifier = Modifier.fillMaxSize()
            )
        }

        if (showWifiPopup) {
            WifiNetworksPopupModal(
                wifiEnabled = wifiEnabled,
                networks = wifiNetworks,
                onToggleWifi = { wifiEnabled = it },
                onRefreshScan = { /* Trigger WifiManager scan */ },
                onSelectNetwork = { selected ->
                    for (i in wifiNetworks.indices) {
                        val item = wifiNetworks[i]
                        wifiNetworks[i] = item.copy(isConnected = item.ssid == selected.ssid)
                    }
                    showWifiPopup = false
                },
                onDismiss = { showWifiPopup = false }
            )
        }
    }
}
