package com.hasansteamstudio.liquidglass.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class LiquidNotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        // Hook live notifications into UI state / DataStore here
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
