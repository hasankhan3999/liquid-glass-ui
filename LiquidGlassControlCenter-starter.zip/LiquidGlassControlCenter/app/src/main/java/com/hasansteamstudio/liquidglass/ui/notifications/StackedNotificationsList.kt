package com.hasansteamstudio.liquidglass.ui.notifications

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hasansteamstudio.liquidglass.model.NotificationEntry

@Composable
fun StackedNotificationsList(
    notifications: List<NotificationEntry>,
    tintStrength: Float = 0.22f,
    modifier: Modifier = Modifier
) {
    val grouped = remember(notifications) {
        notifications.groupBy { it.packageName }.entries.toList()
    }
    val expandedPackages = remember { mutableStateMapOf<String, Boolean>() }
    val listState = rememberLazyListState()

    LazyColumn(
        state = listState,
        modifier = modifier,
        contentPadding = PaddingValues(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        itemsIndexed(grouped, key = { _, entry -> entry.key }) { index, (pkg, items) ->
            val isExpanded = expandedPackages[pkg] ?: (items.size == 1)
            val firstVisibleIdx = listState.firstVisibleItemIndex
            val distanceFromTop = (index - firstVisibleIdx).coerceAtLeast(-2)

            // Compress slightly as items approach the top edge while scrolling
            val scrollDepthTarget = when {
                distanceFromTop <= 0 -> 0.94f
                distanceFromTop == 1 -> 0.98f
                else -> 1.0f
            }

            val depthScale by animateFloatAsState(
                targetValue = scrollDepthTarget,
                animationSpec = spring(dampingRatio = 0.78f, stiffness = 380f),
                label = "notifScrollScale"
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        scaleX = depthScale
                        scaleY = depthScale
                    }
            ) {
                if (!isExpanded && items.size > 1) {
                    val topItem = items.first()
                    val stackCount = items.size.coerceAtMost(3)
                    for (layer in (stackCount - 1) downTo 0) {
                        val layerScale = 1f - (layer * 0.045f)
                        val layerOffsetY = (layer * 7).dp
                        val layerAlpha = 1f - (layer * 0.16f)
                        GlassNotificationCard(
                            item = topItem,
                            badgeText = if (layer == 0) "${items.size} alerts" else null,
                            tintStrength = tintStrength,
                            modifier = Modifier
                                .padding(top = layerOffsetY)
                                .graphicsLayer {
                                    scaleX = layerScale
                                    scaleY = layerScale
                                    alpha = layerAlpha
                                }
                                .clickable { expandedPackages[pkg] = true }
                        )
                    }
                } else {
                    if (items.size > 1) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = items.first().appName,
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show Less",
                                color = Color.White.copy(alpha = 0.90f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.16f))
                                    .clickable { expandedPackages[pkg] = false }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    items.forEach { entry ->
                        AnimatedVisibility(visible = true) {
                            GlassNotificationCard(
                                item = entry,
                                badgeText = null,
                                tintStrength = tintStrength,
                                modifier = Modifier.padding(vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassNotificationCard(
    item: NotificationEntry,
    badgeText: String?,
    tintStrength: Float,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    val rim = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.68f),
            Color.White.copy(alpha = 0.14f),
            Color.White.copy(alpha = 0.42f)
        )
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF0F0F14).copy(alpha = 0.28f))
            .background(Color.White.copy(alpha = tintStrength.coerceIn(0.12f, 0.50f)))
            .border(1.2.dp, rim, shape)
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = item.appName.uppercase(),
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = badgeText ?: item.timeLabel,
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = item.title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.text,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 13.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
