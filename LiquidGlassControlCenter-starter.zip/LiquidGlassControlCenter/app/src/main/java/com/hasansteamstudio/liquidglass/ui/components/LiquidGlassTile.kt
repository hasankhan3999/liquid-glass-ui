package com.hasansteamstudio.liquidglass.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LiquidGlassTile(
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    cornerRadius: Dp = 26.dp,
    tintStrength: Float = 0.22f,
    enableStretch: Boolean = true,
    onTap: () -> Unit = {},
    onLongTap: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit
) {
    val view = LocalView.current
    val shape = RoundedCornerShape(cornerRadius)

    var isPressed by remember { mutableStateOf(false) }
    var dragStretchX by remember { mutableFloatStateOf(0f) }
    var dragStretchY by remember { mutableFloatStateOf(0f) }

    val bounceSpring = spring<Float>(
        dampingRatio = 0.62f,
        stiffness = 400f
    )

    val baseScale by animateFloatAsState(
        targetValue = if (isPressed) 0.93f else 1.0f,
        animationSpec = bounceSpring,
        label = "glassBaseScale"
    )

    val scaleX by animateFloatAsState(
        targetValue = if (enableStretch) {
            (baseScale + dragStretchX).coerceIn(0.90f, 1.08f)
        } else {
            baseScale
        },
        animationSpec = bounceSpring,
        label = "glassScaleX"
    )

    val scaleY by animateFloatAsState(
        targetValue = if (enableStretch) {
            (baseScale + dragStretchY).coerceIn(0.90f, 1.08f)
        } else {
            baseScale
        },
        animationSpec = bounceSpring,
        label = "glassScaleY"
    )

    val fillColor = if (isActive) {
        Color.White
    } else {
        Color.White.copy(alpha = tintStrength.coerceIn(0.12f, 0.55f))
    }

    val darkScrim = if (isActive) {
        Color.Transparent
    } else {
        Color(0xFF0F0F14).copy(alpha = 0.24f)
    }

    val specularBorder = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.72f),
            Color.White.copy(alpha = 0.16f),
            Color.White.copy(alpha = 0.48f)
        )
    )

    Box(
        modifier = modifier
            .graphicsLayer {
                this.scaleX = scaleX
                this.scaleY = scaleY
                this.shape = shape
                clip = true
            }
            .clip(shape)
            .background(darkScrim)
            .background(fillColor)
            .border(
                width = 1.2.dp,
                brush = specularBorder,
                shape = shape
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        val released = tryAwaitRelease()
                        isPressed = false
                        if (released) {
                            onTap()
                        }
                    },
                    onLongPress = {
                        isPressed = false
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        onLongTap()
                    }
                )
            }
            .pointerInput(enableStretch) {
                if (!enableStretch) return@pointerInput
                detectDragGestures(
                    onDragStart = { isPressed = true },
                    onDragEnd = {
                        isPressed = false
                        dragStretchX = 0f
                        dragStretchY = 0f
                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    },
                    onDragCancel = {
                        isPressed = false
                        dragStretchX = 0f
                        dragStretchY = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragStretchX = (dragStretchX + dragAmount.x * 0.0012f).coerceIn(-0.06f, 0.06f)
                        dragStretchY = (dragStretchY + dragAmount.y * 0.0012f).coerceIn(-0.06f, 0.06f)
                    }
                )
            }
            .padding(12.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            content()
        }
    }
}
