package com.hasansteamstudio.liquidglass.model

enum class TileSpan(val colSpan: Int, val rowSpan: Int, val label: String) {
    SIZE_1X1(1, 1, "1x1"),
    SIZE_2X1(2, 1, "2x1"),
    SIZE_1X2(1, 2, "1x2"),
    SIZE_2X2(2, 2, "2x2");

    fun nextEditableSpan(): TileSpan = when (this) {
        SIZE_1X1 -> SIZE_2X1
        SIZE_2X1 -> SIZE_2X2
        SIZE_2X2 -> SIZE_1X1
        SIZE_1X2 -> SIZE_1X2
    }
}

enum class ControlKind {
    WIFI,
    BLUETOOTH,
    CELLULAR,
    AIRPLANE,
    FLASHLIGHT,
    ROTATION_LOCK,
    FOCUS_DND,
    BRIGHTNESS_SLIDER,
    VOLUME_SLIDER,
    MEDIA_PLAYER,
    CUSTOM_APP
}

data class ControlTileItem(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val kind: ControlKind,
    val span: TileSpan = TileSpan.SIZE_1X1,
    val pageIndex: Int = 0,
    val isActive: Boolean = false,
    val packageName: String? = null
)

data class WifiNetworkItem(
    val ssid: String,
    val signalLevel: Int, // 0..4
    val isSecured: Boolean,
    val isConnected: Boolean = false
)

data class NotificationEntry(
    val id: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val timeLabel: String
)
