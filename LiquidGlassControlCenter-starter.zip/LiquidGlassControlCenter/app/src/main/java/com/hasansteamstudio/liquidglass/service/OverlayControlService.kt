package com.hasansteamstudio.liquidglass.service

import android.app.Service
import android.content.Intent
import android.os.IBinder

class OverlayControlService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
