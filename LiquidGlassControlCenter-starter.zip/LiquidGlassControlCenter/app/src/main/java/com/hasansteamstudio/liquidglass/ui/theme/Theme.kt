package com.hasansteamstudio.liquidglass.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkGlassColors = darkColorScheme(
    primary = Color.White,
    onPrimary = Color(0xFF111111),
    background = Color(0xFF0A0B10),
    onBackground = Color.White,
    surface = Color(0xFF14161F),
    onSurface = Color.White
)

@Composable
fun LiquidGlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkGlassColors,
        content = content
    )
}
